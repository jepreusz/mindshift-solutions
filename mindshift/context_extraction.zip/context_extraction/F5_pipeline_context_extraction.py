import re
import os
import pandas as pd
import spacy
from subject_object_extraction import findSVOs

def get_np(parsed_doc):
    '''
    doc:'this is a test msg'
    nps:['np1','np2',...]
    '''
    nps = []
    for np in parsed_doc.noun_chunks:
        nps.append(np)
    return nps

def is_useful_np(np):
    np_list = np.split(' ')
    punct_words = ['a ','an ','the ','this ','that ','these ','those ']
    return len(np_list)>=3 or (not any(map(lambda x: x in np.lower(),punct_words)))

def get_useful_nps(nps):
    return filter(is_useful_np,
                  map(lambda x:x.string[:-1] if x.string[-1]==' ' else x.string,nps))

def wipe_useless_words(doc):
    '''
    doc:'   Impact:this is a test msg.   '
    new_doc:'this is a test msg.'
    '''
    new_doc = re.sub(' {2,}Impact {2,}',' ',doc)
    new_doc = re.sub(' {2,}','',new_doc)
    new_doc = re.sub('.Note:','. ',new_doc)
    return new_doc

def yield_parsed_document(list_of_documents):
    for parsed_document in nlp.pipe(list_of_documents,
                                  batch_size=10000, n_threads=4):
        yield parsed_document

print 'Loading spacy english corpus...'
nlp = spacy.load('en')
print 'Loading complete'

# read file
files_path = './files'
file_path = os.path.join(files_path,'F5_concat_detail_normalized_bigram.xlsx')
data = pd.read_excel(file_path)
docs = data.clean_detail

data = data.iloc[:,:4] # drop synonym and normalized column since they don't perform well on dependency parsing function

# get tight detail
print 'Transform clean detail into tight detail'
tight_detail = map(wipe_useless_words,docs)

# nlp pipeline for finding Subject-Verb-Object phrases
all_SVOs,all_nps = [],[]
import time

start = time.time()
print 'Get Noun phrases...'
for parsed_doc in yield_parsed_document(tight_detail):
    nps = get_np(parsed_doc)
    all_nps.append(nps)
print 'Done. Time used:',time.time()-start

start = time.time()
print 'Get Subject-Verb-Object phrases...'
for parsed_doc in yield_parsed_document(tight_detail):
    all_SVOs.append(findSVOs(parsed_doc))
print 'Done. Time used:',time.time()-start

# add into columns
data['tight_detail'] = tight_detail
data['noun_phrases'] = all_nps
useful_nps = filter(map(is_useful_np,all_nps))
data['useful_nps'] = useful_nps
data['SVO_arc'] = all_SVOs

# write result file
file_path = os.path.join(files_path,'F5_context_extraction.xlsx')
if not os.path.isfile(file_path):
    print 'Writing {}'.format(file_path)
    data.to_excel(file_path,encoding='utf_8')
